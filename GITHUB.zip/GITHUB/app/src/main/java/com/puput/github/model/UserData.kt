package com.puput.github


import com.puput.github.model.UserList

data class UserData(val items : ArrayList<UserList>)
